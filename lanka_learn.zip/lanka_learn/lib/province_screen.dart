import 'package:flutter/material.dart';
import 'data/provinces_data.dart';
import 'quiz_screen.dart';

class ProvinceScreen extends StatefulWidget {
  final Province province;
  final String language;

  const ProvinceScreen({
    super.key,
    required this.province,
    required this.language,
  });

  @override
  State<ProvinceScreen> createState() => _ProvinceScreenState();
}

class _ProvinceScreenState extends State<ProvinceScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  String getProvinceName() {
    if (widget.language == 'Sinhala') return widget.province.nameSi;
    if (widget.language == 'Tamil') return widget.province.nameTa;
    return widget.province.nameEn;
  }

  String getAnimalName(Animal a) {
    if (widget.language == 'Sinhala') return a.nameSi;
    if (widget.language == 'Tamil') return a.nameTa;
    return a.nameEn;
  }

  String getAnimalDesc(Animal a) {
    if (widget.language == 'Sinhala') return a.descSi;
    if (widget.language == 'Tamil') return a.descTa;
    return a.descEn;
  }

  String getRiverName(River r) {
    if (widget.language == 'Sinhala') return r.nameSi;
    if (widget.language == 'Tamil') return r.nameTa;
    return r.nameEn;
  }

  String getRiverDesc(River r) {
    if (widget.language == 'Sinhala') return r.descSi;
    if (widget.language == 'Tamil') return r.descTa;
    return r.descEn;
  }

  String getAnimalsTab() {
    if (widget.language == 'Sinhala') return '🐘 සතුන්';
    if (widget.language == 'Tamil') return '🐘 விலங்குகள்';
    return '🐘 Animals';
  }

  String getRiversTab() {
    if (widget.language == 'Sinhala') return '🌊 ගංඟා';
    if (widget.language == 'Tamil') return '🌊 ஆறுகள்';
    return '🌊 Rivers';
  }

  String getQuizButton() {
    if (widget.language == 'Sinhala') return '🎮 ප්‍රශ්නෝත්තර ක්‍රීඩාව';
    if (widget.language == 'Tamil') return '🎮 வினாடி வினா விளையாட்டு';
    return '🎮 Play Quiz Game';
  }

  String getVideoLabel() {
    if (widget.language == 'Sinhala') return '▶ වීඩියෝව නරඹන්න';
    if (widget.language == 'Tamil') return '▶ வீடியோவை பாருங்கள்';
    return '▶ Watch Video';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF0D47A1), Color(0xFF1976D2), Color(0xFFE3F2FD)],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(context),
              _buildTabBar(),
              Expanded(
                child: Container(
                  color: const Color(0xFFF5F5F5),
                  child: TabBarView(
                    controller: _tabController,
                    children: [
                      _buildAnimalsList(),
                      _buildRiversList(),
                    ],
                  ),
                ),
              ),
              // _buildQuizButton(context),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.white24,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(Icons.arrow_back, color: Colors.white),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.province.emoji + ' ' + getProvinceName(),
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                Text(
                  '${widget.province.animals.length} animals • ${widget.province.rivers.length} rivers',
                  style: const TextStyle(fontSize: 12, color: Colors.white70),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabBar() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white24,
        borderRadius: BorderRadius.circular(30),
      ),
      child: TabBar(
        controller: _tabController,
        indicator: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(30),
        ),
        labelColor: const Color(0xFF0D47A1),
        unselectedLabelColor: Colors.white,
        labelStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
        tabs: [
          Tab(text: getAnimalsTab()),
          Tab(text: getRiversTab()),
        ],
      ),
    );
  }

  Widget _buildAnimalsList() {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: widget.province.animals.length,
      itemBuilder: (context, index) {
        final animal = widget.province.animals[index];
        return _buildCard(
          emoji: animal.emoji,
          name: getAnimalName(animal),
          desc: getAnimalDesc(animal),
          color: const Color(0xFF2E7D32),
        );
      },
    );
  }

  Widget _buildRiversList() {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: widget.province.rivers.length,
      itemBuilder: (context, index) {
        final river = widget.province.rivers[index];
        return _buildCard(
          emoji: river.emoji,
          name: getRiverName(river),
          desc: getRiverDesc(river),
          color: const Color(0xFF1565C0),
        );
      },
    );
  }

  Widget _buildCard({
    required String emoji,
    required String name,
    required String desc,
    required Color color,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Container(
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Center(
                    child: Text(emoji, style: const TextStyle(fontSize: 32)),
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        name,
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: color,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        desc,
                        style: const TextStyle(
                          fontSize: 13,
                          color: Colors.black54,
                          height: 1.4,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('📹 Video for $name coming soon!'),
                  backgroundColor: color,
                  duration: const Duration(seconds: 2),
                ),
              );
            },
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 10),
              decoration: BoxDecoration(
                color: color.withOpacity(0.08),
                borderRadius: const BorderRadius.only(
                  bottomLeft: Radius.circular(16),
                  bottomRight: Radius.circular(16),
                ),
              ),
              child: Center(
                child: Text(
                  getVideoLabel(),
                  style: TextStyle(
                    color: color,
                    fontWeight: FontWeight.w600,
                    fontSize: 13,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Widget _buildQuizButton(BuildContext context) {
  //   return Container(
  //     color: const Color(0xFFF5F5F5),
  //     padding: const EdgeInsets.all(16),
  //     child: SizedBox(
  //       width: double.infinity,
  //       child: ElevatedButton(
  //         onPressed: () {
  //           Navigator.push(
  //             context,
  //             MaterialPageRoute(
  //               builder: (_) => QuizScreen(
  //                 province: widget.province,
  //                 language: widget.language,
  //               ),
  //             ),
  //           );
  //         },
  //         style: ElevatedButton.styleFrom(
  //           backgroundColor: const Color(0xFF0D47A1),
  //           foregroundColor: Colors.white,
  //           padding: const EdgeInsets.symmetric(vertical: 16),
  //           shape: RoundedRectangleBorder(
  //             borderRadius: BorderRadius.circular(16),
  //           ),
  //           elevation: 4,
  //         ),
  //         child: Text(
  //           getQuizButton(),
  //           style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
  //         ),
  //       ),
  //     ),
  //   );
  // }
}