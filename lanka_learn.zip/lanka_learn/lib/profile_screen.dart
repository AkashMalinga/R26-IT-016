import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ProfileScreen extends StatefulWidget {
  final String language;
  final Function(String) onLanguageChange;

  const ProfileScreen({
    super.key,
    required this.language,
    required this.onLanguageChange,
  });

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final TextEditingController _nameController = TextEditingController();
  String _selectedAvatar = '🦁';
  String _selectedLanguage = 'English';
  bool _saved = false;

  final List<String> _avatars = [
    '🦁', '🐘', '🐬', '🦚', '🐆', '🐒',
    '🦋', '🐢', '🦜', '🐋', '🦩', '🐻',
  ];

  @override
  void initState() {
    super.initState();
    _selectedLanguage = widget.language;
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _nameController.text = prefs.getString('name') ?? '';
      _selectedAvatar = prefs.getString('avatar') ?? '🦁';
      _selectedLanguage = prefs.getString('language') ?? 'English';
    });
  }

  Future<void> _saveProfile() async {
    if (_nameController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(_getEnterNameMsg()),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('name', _nameController.text.trim());
    await prefs.setString('avatar', _selectedAvatar);
    await prefs.setString('language', _selectedLanguage);
    widget.onLanguageChange(_selectedLanguage);
    setState(() => _saved = true);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(_getSavedMsg()),
        backgroundColor: const Color(0xFF2E7D32),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  String _getTitle() {
    if (widget.language == 'Sinhala') return 'මගේ පැතිකඩ';
    if (widget.language == 'Tamil') return 'என் சுயவிவரம்';
    return 'My Profile';
  }

  String _getNameLabel() {
    if (widget.language == 'Sinhala') return 'ඔබේ නම';
    if (widget.language == 'Tamil') return 'உங்கள் பெயர்';
    return 'Your Name';
  }

  String _getAvatarLabel() {
    if (widget.language == 'Sinhala') return 'ඔබේ අවතාරය තෝරන්න';
    if (widget.language == 'Tamil') return 'உங்கள் அவதாரத்தை தேர்ந்தெடுக்கவும்';
    return 'Choose Your Avatar';
  }

  String _getLanguageLabel() {
    if (widget.language == 'Sinhala') return 'භාෂාව තෝරන්න';
    if (widget.language == 'Tamil') return 'மொழியை தேர்ந்தெடுக்கவும்';
    return 'Choose Language';
  }

  String _getSaveLabel() {
    if (widget.language == 'Sinhala') return '💾 සුරකින්න';
    if (widget.language == 'Tamil') return '💾 சேமிக்கவும்';
    return '💾 Save Profile';
  }

  String _getSavedMsg() {
    if (widget.language == 'Sinhala') return 'පැතිකඩ සාර්ථකව සුරකින ලදී!';
    if (widget.language == 'Tamil') return 'சுயவிவரம் வெற்றிகரமாக சேமிக்கப்பட்டது!';
    return 'Profile saved successfully!';
  }

  String _getEnterNameMsg() {
    if (widget.language == 'Sinhala') return 'කරුණාකර ඔබේ නම ඇතුළත් කරන්න';
    if (widget.language == 'Tamil') return 'தயவுசெய்து உங்கள் பெயரை உள்ளிடவும்';
    return 'Please enter your name';
  }

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF880E4F), Color(0xFFE91E63), Color(0xFFFCE4EC)],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                const SizedBox(height: 10),
                _buildAvatarDisplay(),
                const SizedBox(height: 24),
                _buildNameField(),
                const SizedBox(height: 20),
                _buildAvatarPicker(),
                const SizedBox(height: 20),
                _buildLanguagePicker(),
                const SizedBox(height: 30),
                _buildSaveButton(),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildAvatarDisplay() {
    return Column(
      children: [
        Container(
          width: 100,
          height: 100,
          decoration: BoxDecoration(
            color: Colors.white,
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.2),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Center(
            child: Text(
              _selectedAvatar,
              style: const TextStyle(fontSize: 52),
            ),
          ),
        ),
        const SizedBox(height: 12),
        Text(
          _getTitle(),
          style: const TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
      ],
    );
  }

  Widget _buildNameField() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            _getNameLabel(),
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              color: Color(0xFF880E4F),
              fontSize: 14,
            ),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _nameController,
            decoration: InputDecoration(
              hintText: '✏️ Enter your name...',
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: const BorderSide(color: Color(0xFFE91E63)),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: const BorderSide(
                  color: Color(0xFFE91E63),
                  width: 2,
                ),
              ),
            ),
            style: const TextStyle(fontSize: 16),
          ),
        ],
      ),
    );
  }

  Widget _buildAvatarPicker() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            _getAvatarLabel(),
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              color: Color(0xFF880E4F),
              fontSize: 14,
            ),
          ),
          const SizedBox(height: 12),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 6,
              crossAxisSpacing: 8,
              mainAxisSpacing: 8,
            ),
            itemCount: _avatars.length,
            itemBuilder: (context, index) {
              final avatar = _avatars[index];
              final selected = avatar == _selectedAvatar;
              return GestureDetector(
                onTap: () => setState(() => _selectedAvatar = avatar),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  decoration: BoxDecoration(
                    color: selected
                        ? const Color(0xFFFCE4EC)
                        : Colors.grey.shade100,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: selected
                          ? const Color(0xFFE91E63)
                          : Colors.transparent,
                      width: 2,
                    ),
                  ),
                  child: Center(
                    child: Text(
                      avatar,
                      style: const TextStyle(fontSize: 24),
                    ),
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildLanguagePicker() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            _getLanguageLabel(),
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              color: Color(0xFF880E4F),
              fontSize: 14,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: ['English', 'Sinhala', 'Tamil'].map((lang) {
              final selected = _selectedLanguage == lang;
              return Expanded(
                child: GestureDetector(
                  onTap: () => setState(() => _selectedLanguage = lang),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    decoration: BoxDecoration(
                      color: selected
                          ? const Color(0xFFE91E63)
                          : Colors.grey.shade100,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      children: [
                        Text(
                          lang == 'English'
                              ? '🇬🇧'
                              : lang == 'Sinhala'
                                  ? '🇱🇰'
                                  : '🇮🇳',
                          style: const TextStyle(fontSize: 20),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          lang,
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                            color: selected ? Colors.white : Colors.black54,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildSaveButton() {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: _saveProfile,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.white,
          foregroundColor: const Color(0xFF880E4F),
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          elevation: 4,
        ),
        child: Text(
          _getSaveLabel(),
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}