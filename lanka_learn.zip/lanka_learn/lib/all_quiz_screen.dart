import 'package:flutter/material.dart';
import 'data/provinces_data.dart';
import 'quiz_screen.dart';

class AllQuizScreen extends StatelessWidget {
  final String language;

  const AllQuizScreen({super.key, required this.language});

  String getTitle() {
    if (language == 'Sinhala') return 'ප්‍රශ්නෝත්තර ක්‍රීඩා';
    if (language == 'Tamil') return 'வினாடி வினா விளையாட்டுகள்';
    return 'Quiz Games';
  }

  String getSubtitle() {
    if (language == 'Sinhala') return 'පළාතක් තෝරා ක්‍රීඩා කරන්න!';
    if (language == 'Tamil') return 'ஒரு மாகாணத்தை தேர்ந்தெடுத்து விளையாடுங்கள்!';
    return 'Pick a province and start playing!';
  }

  String getProvinceName(Province p) {
    if (language == 'Sinhala') return p.nameSi;
    if (language == 'Tamil') return p.nameTa;
    return p.nameEn;
  }

  String getQuestionsLabel(Province p) {
    int total = p.animals.length + p.rivers.length;
    if (language == 'Sinhala') return '$total ප්‍රශ්න';
    if (language == 'Tamil') return '$total கேள்விகள்';
    return '$total Questions';
  }

  String getPlayLabel() {
    if (language == 'Sinhala') return 'ක්‍රීඩා කරන්න';
    if (language == 'Tamil') return 'விளையாடு';
    return 'Play';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF4A148C),
              Color(0xFF7B1FA2),
              Color(0xFFF3E5F5),
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              Expanded(child: _buildQuizList(context)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          const Text('🎮', style: TextStyle(fontSize: 50)),
          const SizedBox(height: 8),
          Text(
            getTitle(),
            style: const TextStyle(
              fontSize: 26,
              fontWeight: FontWeight.bold,
              color: Colors.white,
              shadows: [Shadow(color: Colors.black26, blurRadius: 4)],
            ),
          ),
          const SizedBox(height: 4),
          Text(
            getSubtitle(),
            style: const TextStyle(fontSize: 13, color: Colors.white70),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildQuizList(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      itemCount: provinces.length,
      itemBuilder: (context, index) {
        final province = provinces[index];
        return _buildQuizCard(context, province, index);
      },
    );
  }

  Widget _buildQuizCard(BuildContext context, Province province, int index) {
    final colors = [
      [const Color(0xFF1B5E20), const Color(0xFF4CAF50)],
      [const Color(0xFF0D47A1), const Color(0xFF2196F3)],
      [const Color(0xFF880E4F), const Color(0xFFE91E63)],
      [const Color(0xFFE65100), const Color(0xFFFF9800)],
      [const Color(0xFF006064), const Color(0xFF00BCD4)],
      [const Color(0xFF4A148C), const Color(0xFF9C27B0)],
      [const Color(0xFF1A237E), const Color(0xFF3F51B5)],
      [const Color(0xFF33691E), const Color(0xFF8BC34A)],
      [const Color(0xFF37474F), const Color(0xFF607D8B)],
    ];
    final color = colors[index % colors.length];

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: color),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: color[0].withOpacity(0.4),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => QuizScreen(
                  province: province,
                  language: language,
                ),
              ),
            );
          },
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Container(
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration(
                    color: Colors.white24,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Center(
                    child: Text(
                      province.emoji,
                      style: const TextStyle(fontSize: 32),
                    ),
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        getProvinceName(province),
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        getQuestionsLabel(province),
                        style: const TextStyle(
                          fontSize: 13,
                          color: Colors.white70,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 8,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    getPlayLabel(),
                    style: TextStyle(
                      color: color[0],
                      fontWeight: FontWeight.bold,
                      fontSize: 13,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}