class Province {
  final String nameEn;
  final String nameSi;
  final String nameTa;
  final String emoji;
  final List<Animal> animals;
  final List<River> rivers;

  Province({
    required this.nameEn,
    required this.nameSi,
    required this.nameTa,
    required this.emoji,
    required this.animals,
    required this.rivers,
  });
}

class Animal {
  final String nameEn;
  final String nameSi;
  final String nameTa;
  final String emoji;
  final String descEn;
  final String descSi;
  final String descTa;

  Animal({
    required this.nameEn,
    required this.nameSi,
    required this.nameTa,
    required this.emoji,
    required this.descEn,
    required this.descSi,
    required this.descTa,
  });
}

class River {
  final String nameEn;
  final String nameSi;
  final String nameTa;
  final String emoji;
  final String descEn;
  final String descSi;
  final String descTa;

  River({
    required this.nameEn,
    required this.nameSi,
    required this.nameTa,
    required this.emoji,
    required this.descEn,
    required this.descSi,
    required this.descTa,
  });
}

final List<Province> provinces = [
  Province(
    nameEn: 'Western Province',
    nameSi: 'බස්නාහිර පළාත',
    nameTa: 'மேல் மாகாணம்',
    emoji: '🏙️',
    animals: [
      Animal(
        nameEn: 'Purple-faced Langur',
        nameSi: 'වේදරු මූණු වදුරා',
        nameTa: 'ஊதா முக லங்கூர்',
        emoji: '🐒',
        descEn: 'A rare monkey found in wet zone forests of Western Province.',
        descSi: 'බස්නාහිර පළාතේ තෙත් කලාප වනාන්තරවල දක්නට ලැබෙන දුර්ලභ වදුරෙකි.',
        descTa: 'மேல் மாகாணத்தின் ஈர மண்டல காடுகளில் காணப்படும் அரிய குரங்கு.',
      ),
      Animal(
        nameEn: 'Fishing Cat',
        nameSi: 'ගොළු දිවියා',
        nameTa: 'மீன்பிடி பூனை',
        emoji: '🐱',
        descEn: 'A wild cat that lives near wetlands and rivers, good at swimming.',
        descSi: 'තෙත්බිම් හා ගංඟා අසල වාසය කරන, පිහිනීමට දක්ෂ වන බළලෙකි.',
        descTa: 'நீர்நிலைகள் மற்றும் ஆறுகளுக்கு அருகில் வாழும் காட்டு பூனை.',
      ),
    ],
    rivers: [
      River(
        nameEn: 'Kelani River',
        nameSi: 'කැලණි ගඟ',
        nameTa: 'கேலானி நதி',
        emoji: '🌊',
        descEn: 'The main river of Western Province, flows through Colombo.',
        descSi: 'බස්නාහිර පළාතේ ප්‍රධාන ගඟ වන මෙය කොළඹ හරහා ගලා යයි.',
        descTa: 'மேல் மாகாணத்தின் பிரதான ஆறு, கொழும்பு வழியாக பாய்கிறது.',
      ),
      River(
        nameEn: 'Kalu River',
        nameSi: 'කළු ගඟ',
        nameTa: 'காலு நதி',
        emoji: '🌊',
        descEn: 'One of the largest rivers in Sri Lanka, flows through Ratnapura.',
        descSi: 'ශ්‍රී ලංකාවේ විශාලතම ගංඟාවලින් එකක් වන මෙය රත්නපුර හරහා ගලා යයි.',
        descTa: 'இலங்கையின் மிகப்பெரிய ஆறுகளில் ஒன்று, இரத்தினபுரி வழியாக பாய்கிறது.',
      ),
    ],
  ),
  Province(
    nameEn: 'Central Province',
    nameSi: 'මධ්‍යම පළාත',
    nameTa: 'மத்திய மாகாணம்',
    emoji: '🏔️',
    animals: [
      Animal(
        nameEn: 'Sri Lanka Leopard',
        nameSi: 'ශ්‍රී ලංකා දිවියා',
        nameTa: 'இலங்கை சிறுத்தை',
        emoji: '🐆',
        descEn: 'A magnificent big cat found in the hill country forests.',
        descSi: 'කඳුකර වනාන්තරවල දක්නට ලැබෙන අසිරිමත් විශාල බළලෙකි.',
        descTa: 'மலை நாட்டு காடுகளில் காணப்படும் அற்புதமான பெரிய பூனை.',
      ),
      Animal(
        nameEn: 'Sri Lanka Sambar Deer',
        nameSi: 'මුව',
        nameTa: 'சாம்பார் மான்',
        emoji: '🦌',
        descEn: 'Large deer found in mountain forests of Central Province.',
        descSi: 'මධ්‍යම පළාතේ කඳු වනාන්තරවල දක්නට ලැබෙන විශාල මුවෙකි.',
        descTa: 'மத்திய மாகாணத்தின் மலை காடுகளில் காணப்படும் பெரிய மான்.',
      ),
    ],
    rivers: [
      River(
        nameEn: 'Mahaweli River',
        nameSi: 'මහවැලි ගඟ',
        nameTa: 'மகாவலி நதி',
        emoji: '🌊',
        descEn: 'The longest river in Sri Lanka, originates from Central Province.',
        descSi: 'ශ්‍රී ලංකාවේ දිගම ගඟ වන මෙය මධ්‍යම පළාතේ සිට ආරම්භ වේ.',
        descTa: 'இலங்கையின் நீளமான ஆறு, மத்திய மாகாணத்தில் தோன்றுகிறது.',
      ),
      River(
        nameEn: 'Kotmale River',
        nameSi: 'කෝට්මලේ ගඟ',
        nameTa: 'கொட்மலை நதி',
        emoji: '🌊',
        descEn: 'A tributary of Mahaweli River, known for Kotmale Reservoir.',
        descSi: 'කෝට්මලේ ජලාශය සඳහා ප්‍රසිද්ධ මහවැලි ගඟේ අතු ගඟකි.',
        descTa: 'கொட்மலை நீர்த்தேக்கத்திற்கு பிரசித்தமான மகாவலியின் கிளை ஆறு.',
      ),
    ],
  ),
  Province(
    nameEn: 'Southern Province',
    nameSi: 'දකුණු පළාත',
    nameTa: 'தெற்கு மாகாணம்',
    emoji: '🌴',
    animals: [
      Animal(
        nameEn: 'Blue Whale',
        nameSi: 'නිල් තිමිංගලයා',
        nameTa: 'நீல திமிங்கலம்',
        emoji: '🐋',
        descEn: 'The largest animal on Earth, seen off the coast of Mirissa.',
        descSi: 'පොළොවේ විශාලතම සතා වන මෙය මිරිස්ස වෙරළ අසල දැකිය හැකිය.',
        descTa: 'பூமியின் மிகப்பெரிய விலங்கு, மிரிஸ்ஸா கடற்கரையில் காணலாம்.',
      ),
      Animal(
        nameEn: 'Sri Lanka Elephant',
        nameSi: 'ශ්‍රී ලංකා අලියා',
        nameTa: 'இலங்கை யானை',
        emoji: '🐘',
        descEn: 'Asian elephants roam freely in Udawalawe National Park.',
        descSi: 'උඩවලව ජාතික වනෝද්‍යානයේ ආසියානු අලින් නිදහසේ සැරිසරති.',
        descTa: 'உடவலவே தேசிய பூங்காவில் ஆசிய யானைகள் சுதந்திரமாக திரிகின்றன.',
      ),
    ],
    rivers: [
      River(
        nameEn: 'Nilwala River',
        nameSi: 'නිල්වලා ගඟ',
        nameTa: 'நில்வாலா நதி',
        emoji: '🌊',
        descEn: 'Main river of Southern Province, flows through Matara.',
        descSi: 'දකුණු පළාතේ ප්‍රධාน ගඟ වන මෙය මාතර හරහා ගලා යයි.',
        descTa: 'தெற்கு மாகாணத்தின் பிரதான ஆறு, மாத்தறை வழியாக பாய்கிறது.',
      ),
      River(
        nameEn: 'Gin River',
        nameSi: 'ගිං ගඟ',
        nameTa: 'கின் நதி',
        emoji: '🌊',
        descEn: 'A river flowing through Galle district in Southern Province.',
        descSi: 'දකුණු පළාතේ ගාල්ල දිස්ත්‍රික්කය හරහා ගලා යන ගඟකි.',
        descTa: 'தெற்கு மாகாணத்தின் காலி மாவட்டம் வழியாக பாயும் ஆறு.',
      ),
    ],
  ),
  Province(
    nameEn: 'Northern Province',
    nameSi: 'උතුරු පළාත',
    nameTa: 'வட மாகாணம்',
    emoji: '🦚',
    animals: [
      Animal(
        nameEn: 'Indian Peafowl',
        nameSi: 'මොණරා',
        nameTa: 'மயில்',
        emoji: '🦚',
        descEn: 'The national bird of India, commonly seen in Northern Province.',
        descSi: 'ඉන්දියාවේ ජාතික පක්ෂියා වන මොණරා උතුරු පළාතේ බහුලව දැකිය හැකිය.',
        descTa: 'இந்தியாவின் தேசிய பறவை, வட மாகாணத்தில் அதிகமாக காணப்படுகிறது.',
      ),
      Animal(
        nameEn: 'Flamingo',
        nameSi: 'ෆ්ලැමිංගෝ',
        nameTa: 'ஃப்ளமிங்கோ',
        emoji: '🦩',
        descEn: 'Pink flamingos visit the lagoons of Northern Province seasonally.',
        descSi: 'රෝස ෆ්ලැමිංගෝ සෘතුමය ලෙස උතුරු පළාතේ කලපු වෙත පැමිණේ.',
        descTa: 'இளஞ்சிவப்பு ஃப்ளமிங்கோக்கள் வட மாகாணத்தின் நீர்நிலைகளுக்கு வருகை தருகின்றன.',
      ),
    ],
    rivers: [
      River(
        nameEn: 'Aruvi Aru River',
        nameSi: 'අරුවි ආරු ගඟ',
        nameTa: 'அருவி ஆறு',
        emoji: '🌊',
        descEn: 'Major river of Northern Province flowing into the sea near Mannar.',
        descSi: 'උතුරු පළාතේ ප්‍රධාන ගඟ වන මෙය මන්නාරම අසල මුහුදට වැටේ.',
        descTa: 'வட மாகாணத்தின் முக்கிய ஆறு, மன்னார் அருகே கடலில் கலக்கிறது.',
      ),
      River(
        nameEn: 'Iranamadu River',
        nameSi: 'ඉරාණමඩු ගඟ',
        nameTa: 'இராணமடு நதி',
        emoji: '🌊',
        descEn: 'Feeds the Iranamadu Tank, an important water source in the North.',
        descSi: 'උතුරේ වැදගත් ජල ප්‍රභවයක් වන ඉරාණමඩු වැව පෝෂණය කරයි.',
        descTa: 'வடக்கில் முக்கிய நீர் ஆதாரமான இராணமடு தொட்டியை நிரப்புகிறது.',
      ),
    ],
  ),
  Province(
    nameEn: 'Eastern Province',
    nameSi: 'නැගෙනහිර පළාත',
    nameTa: 'கிழக்கு மாகாணம்',
    emoji: '🐬',
    animals: [
      Animal(
        nameEn: 'Spinner Dolphin',
        nameSi: 'ස්පිනර් ඩොල්ෆින්',
        nameTa: 'ஸ்பின்னர் டால்பின்',
        emoji: '🐬',
        descEn: 'Playful dolphins seen in large pods off Trincomalee coast.',
        descSi: 'ත්‍රිකුණාමළය වෙරළ අසල විශාල රංචු වලින් දැකිය හැකි ඩොල්ෆිනුන්.',
        descTa: 'திருகோணமலை கடற்கரையில் பெரிய கூட்டங்களாக காணப்படும் டால்பின்கள்.',
      ),
      Animal(
        nameEn: 'Sea Turtle',
        nameSi: 'මුහුදු කැස්බෑවා',
        nameTa: 'கடல் ஆமை',
        emoji: '🐢',
        descEn: 'Sea turtles nest on the beautiful beaches of Eastern Province.',
        descSi: 'නැගෙනහිර පළාතේ සුන්දර වෙරළෙහි මුහුදු කැස්බෑවන් බිත්තර දමති.',
        descTa: 'கிழக்கு மாகாணத்தின் அழகான கடற்கரைகளில் கடல் ஆமைகள் முட்டையிடுகின்றன.',
      ),
    ],
    rivers: [
      River(
        nameEn: 'Mahaweli River (East)',
        nameSi: 'මහවැලි ගඟ (නැගෙනහිර)',
        nameTa: 'மகாவலி நதி (கிழக்கு)',
        emoji: '🌊',
        descEn: 'Mahaweli River empties into the sea at Trincomalee in the East.',
        descSi: 'මහවැලි ගඟ නැගෙනහිර ත්‍රිකුණාමළයේදී මුහුදට වැටේ.',
        descTa: 'மகாவலி ஆறு கிழக்கில் திருகோணமலையில் கடலில் கலக்கிறது.',
      ),
      River(
        nameEn: 'Gal Oya River',
        nameSi: 'ගල් ඔය ගඟ',
        nameTa: 'கல் ஓயா நதி',
        emoji: '🌊',
        descEn: 'Feeds the Senanayake Samudra reservoir in Eastern Province.',
        descSi: 'නැගෙනහිර පළාතේ සේනානායක සමුද්‍රය ජලාශය පෝෂණය කරයි.',
        descTa: 'கிழக்கு மாகாணத்தில் சேனாநாயக்க சமுத்திரம் நீர்த்தேக்கத்தை நிரப்புகிறது.',
      ),
    ],
  ),
  Province(
    nameEn: 'North Western Province',
    nameSi: 'වයඹ පළාත',
    nameTa: 'வடமேல் மாகாணம்',
    emoji: '🦜',
    animals: [
      Animal(
        nameEn: 'Painted Stork',
        nameSi: 'පින්තාරු කොකා',
        nameTa: 'வர்ணம் தீட்டிய நாரை',
        emoji: '🦜',
        descEn: 'Beautiful wading birds found in wetlands of North Western Province.',
        descSi: 'වයඹ පළාතේ තෙත්බිම්වල දක්නට ලැබෙන සුන්දර ජල පක්ෂීන්.',
        descTa: 'வடமேல் மாகாணத்தின் ஈரநிலங்களில் காணப்படும் அழகான நீர் பறவைகள்.',
      ),
      Animal(
        nameEn: 'Mugger Crocodile',
        nameSi: 'කිඹුලා',
        nameTa: 'முதலை',
        emoji: '🐊',
        descEn: 'Crocodiles inhabit the rivers and tanks of North Western Province.',
        descSi: 'වයඹ පළාතේ ගංඟා හා වැව්වල කිඹුලන් වාසය කරති.',
        descTa: 'வடமேல் மாகாணத்தின் ஆறுகள் மற்றும் குளங்களில் முதலைகள் வாழ்கின்றன.',
      ),
    ],
    rivers: [
      River(
        nameEn: 'Deduru Oya River',
        nameSi: 'දැදුරු ඔය',
        nameTa: 'தெதுரு ஓயா நதி',
        emoji: '🌊',
        descEn: 'Major river of North Western Province flowing to the sea.',
        descSi: 'වයඹ පළාතේ ප්‍රධාන ගඟ වන මෙය මුහුදට ගලා යයි.',
        descTa: 'வடமேல் மாகாணத்தின் முக்கிய ஆறு கடலில் கலக்கிறது.',
      ),
      River(
        nameEn: 'Mi Oya River',
        nameSi: 'මී ඔය',
        nameTa: 'மி ஓயா நதி',
        emoji: '🌊',
        descEn: 'Flows through Puttalam district in North Western Province.',
        descSi: 'වයඹ පළාතේ පුත්තලම් දිස්ත්‍රික්කය හරහා ගලා යයි.',
        descTa: 'வடமேல் மாகாணத்தின் புத்தளம் மாவட்டம் வழியாக பாய்கிறது.',
      ),
    ],
  ),
  Province(
    nameEn: 'North Central Province',
    nameSi: 'උතුරු මැද පළාත',
    nameTa: 'வடமத்திய மாகாணம்',
    emoji: '🦁',
    animals: [
      Animal(
        nameEn: 'Sloth Bear',
        nameSi: 'වලසා',
        nameTa: 'சோம்பேறி கரடி',
        emoji: '🐻',
        descEn: 'Shaggy bears found in the dry forests of North Central Province.',
        descSi: 'උතුරු මැද පළාතේ වියළි වනාන්තරවල දක්නට ලැබෙන වලසුන්.',
        descTa: 'வடமத்திய மாகாணத்தின் வறண்ட காடுகளில் காணப்படும் கரடிகள்.',
      ),
      Animal(
        nameEn: 'Sri Lanka Elephant',
        nameSi: 'ශ්‍රී ලංකා අලියා',
        nameTa: 'இலங்கை யானை',
        emoji: '🐘',
        descEn: 'Large herds of elephants roam in Minneriya National Park.',
        descSi: 'මිනේරිය ජාතික වනෝද්‍යානයේ අලි රංචු නිදහසේ සැරිසරති.',
        descTa: 'மினேரியா தேசிய பூங்காவில் பெரிய யானை மந்தைகள் திரிகின்றன.',
      ),
    ],
    rivers: [
      River(
        nameEn: 'Malwathu Oya River',
        nameSi: 'මල්වතු ඔය',
        nameTa: 'மல்வத்து ஓயா நதி',
        emoji: '🌊',
        descEn: 'Flows through Anuradhapura, the ancient capital of Sri Lanka.',
        descSi: 'ශ්‍රී ලංකාවේ පුරාණ අගනගරය වන අනුරාධපුරය හරහා ගලා යයි.',
        descTa: 'இலங்கையின் பண்டைய தலைநகரான அனுராதபுரம் வழியாக பாய்கிறது.',
      ),
      River(
        nameEn: 'Kala Oya River',
        nameSi: 'කලා ඔය',
        nameTa: 'கலா ஓயா நதி',
        emoji: '🌊',
        descEn: 'Feeds Kala Wewa, an ancient reservoir built by King Dhatusena.',
        descSi: 'රජ දාතුසේන රජු විසින් ඉදිකරන ලද පුරාණ කලා වැව පෝෂණය කරයි.',
        descTa: 'தாதுசேன மன்னரால் கட்டப்பட்ட பண்டைய கலா வேவாவை நிரப்புகிறது.',
      ),
    ],
  ),
  Province(
    nameEn: 'Uva Province',
    nameSi: 'ඌව පළාත',
    nameTa: 'ஊவா மாகாணம்',
    emoji: '🍃',
    animals: [
      Animal(
        nameEn: 'Sri Lanka Leopard',
        nameSi: 'ශ්‍රී ලංකා දිවියා',
        nameTa: 'இலங்கை சிறுத்தை',
        emoji: '🐆',
        descEn: 'Leopards are spotted in Horton Plains and Yala in Uva Province.',
        descSi: 'ඌව පළාතේ හෝටන් තැන්න හා යාල ප්‍රදේශවල දිවියන් දක්නට ලැබේ.',
        descTa: 'ஊவா மாகாணத்தில் ஹார்ட்டன் சமவெளி மற்றும் யாலாவில் சிறுத்தைகள் காணப்படுகின்றன.',
      ),
      Animal(
        nameEn: 'Sri Lanka Whistling Thrush',
        nameSi: 'ශ්‍රී ලංකා විස්ලිං ත්‍රශ්',
        nameTa: 'இலங்கை விசில் த்ரஷ்',
        emoji: '🐦',
        descEn: 'A rare bird found only in the mountain streams of Uva Province.',
        descSi: 'ඌව පළාතේ කඳු ගංඟාවල පමණක් දැකිය හැකි දුර්ලභ පක්ෂියෙකි.',
        descTa: 'ஊவா மாகாணத்தின் மலை நீரோடைகளில் மட்டுமே காணப்படும் அரிய பறவை.',
      ),
    ],
    rivers: [
      River(
        nameEn: 'Mahaweli River (Uva)',
        nameSi: 'මහවැලි ගඟ (ඌව)',
        nameTa: 'மகாவலி நதி (ஊவா)',
        emoji: '🌊',
        descEn: 'Upper reaches of Mahaweli River flow through Uva Province.',
        descSi: 'මහවැලි ගඟේ ඉහළ ජල ධාරා ඌව පළාත හරහා ගලා යයි.',
        descTa: 'மகாவலி ஆற்றின் மேல் நீரோட்டங்கள் ஊவா மாகாணம் வழியாக பாய்கின்றன.',
      ),
      River(
        nameEn: 'Kirindi Oya River',
        nameSi: 'කිරිඳි ඔය',
        nameTa: 'கிரிண்டி ஓயா நதி',
        emoji: '🌊',
        descEn: 'Flows through Uva Province and feeds Lunugamvehera reservoir.',
        descSi: 'ඌව පළාත හරහා ගලා ගොස් ලුණුගම්වෙහෙර ජලාශය පෝෂණය කරයි.',
        descTa: 'ஊவா மாகாணம் வழியாக பாய்ந்து லுனுகம்வேஹேரா நீர்த்தேக்கத்தை நிரப்புகிறது.',
      ),
    ],
  ),
  Province(
    nameEn: 'Sabaragamuwa Province',
    nameSi: 'සබරගමු පළාත',
    nameTa: 'சபரகமுவ மாகாணம்',
    emoji: '💎',
    animals: [
      Animal(
        nameEn: 'Sri Lanka Leopard',
        nameSi: 'ශ්‍රී ලංකා දිවියා',
        nameTa: 'இலங்கை சிறுத்தை',
        emoji: '🐆',
        descEn: 'Leopards are found in the rainforests of Sabaragamuwa Province.',
        descSi: 'සබරගමු පළාතේ වැසි වනාන්තරවල දිවියන් දක්නට ලැබේ.',
        descTa: 'சபரகமுவ மாகாணத்தின் மழை காடுகளில் சிறுத்தைகள் காணப்படுகின்றன.',
      ),
      Animal(
        nameEn: 'Purple-faced Langur',
        nameSi: 'වේදරු මූණු වදුරා',
        nameTa: 'ஊதா முக லங்கூர்',
        emoji: '🐒',
        descEn: 'Rare monkeys living in the wet forests of Sabaragamuwa.',
        descSi: 'සබරගමු පළාතේ තෙත් වනාන්තරවල ජීවත් වන දුර්ලභ වදුරන්.',
        descTa: 'சபரகமுவாவின் ஈர காடுகளில் வாழும் அரிய குரங்குகள்.',
      ),
    ],
    rivers: [
      River(
        nameEn: 'Kalu River',
        nameSi: 'කළු ගඟ',
        nameTa: 'காலு நதி',
        emoji: '🌊',
        descEn: 'Originates in Sabaragamuwa and flows to Western Province.',
        descSi: 'සබරගමුවේ ආරම්භ වී බස්නාහිර පළාතට ගලා යයි.',
        descTa: 'சபரகமுவாவில் தோன்றி மேல் மாகாணத்திற்கு பாய்கிறது.',
      ),
      River(
        nameEn: 'Kukule River',
        nameSi: 'කුකුළේ ගඟ',
        nameTa: 'குகுலே நதி',
        emoji: '🌊',
        descEn: 'A river in Sabaragamuwa Province known for its scenic beauty.',
        descSi: 'සිනිදු සෞන්දර්යයට ප්‍රසිද්ධ සබරගමු පළාතේ ගඟකි.',
        descTa: 'இயற்கை அழகுக்கு பிரசித்தமான சபரகமுவ மாகாணத்தின் ஆறு.',
      ),
    ],
  ),
];