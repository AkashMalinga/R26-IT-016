import 'package:flutter/material.dart';
import 'data/provinces_data.dart';

class QuizScreen extends StatefulWidget {
  final Province province;
  final String language;

  const QuizScreen({
    super.key,
    required this.province,
    required this.language,
  });

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen>
    with TickerProviderStateMixin {
  int _currentQuestion = 0;
  int _score = 0;
  int? _selectedAnswer;
  bool _answered = false;
  late List<QuizQuestion> _questions;
  late AnimationController _animController;
  late Animation<double> _scaleAnim;

  @override
  void initState() {
    super.initState();
    _questions = _buildQuestions();
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
    _scaleAnim = Tween<double>(begin: 0.8, end: 1.0).animate(
      CurvedAnimation(parent: _animController, curve: Curves.elasticOut),
    );
    _animController.forward();
  }

  @override
  void dispose() {
    _animController.dispose();
    super.dispose();
  }

  List<QuizQuestion> _buildQuestions() {
    List<QuizQuestion> questions = [];

    for (var animal in widget.province.animals) {
      String question, correct;
      List<String> options;

      if (widget.language == 'Sinhala') {
        question = '${animal.emoji} මෙම සතා කුමක්ද?';
        correct = animal.nameSi;
        options = _getAnimalOptions(animal, 'si');
      } else if (widget.language == 'Tamil') {
        question = '${animal.emoji} இந்த விலங்கு எது?';
        correct = animal.nameTa;
        options = _getAnimalOptions(animal, 'ta');
      } else {
        question = '${animal.emoji} What animal is this?';
        correct = animal.nameEn;
        options = _getAnimalOptions(animal, 'en');
      }

      questions.add(QuizQuestion(
        question: question,
        correctAnswer: correct,
        options: options,
        emoji: animal.emoji,
        type: 'animal',
      ));
    }

    for (var river in widget.province.rivers) {
      String question, correct;
      List<String> options;

      if (widget.language == 'Sinhala') {
        question = '🌊 මෙම ගඟ ${_getProvinceName()} පළාතේ ගඟකි. එහි නම කුමක්ද?';
        correct = river.nameSi;
        options = _getRiverOptions(river, 'si');
      } else if (widget.language == 'Tamil') {
        question = '🌊 இந்த ஆறு ${_getProvinceName()} மாகாணத்தில் உள்ளது. அதன் பெயர் என்ன?';
        correct = river.nameTa;
        options = _getRiverOptions(river, 'ta');
      } else {
        question = '🌊 This river is in ${_getProvinceName()}. What is its name?';
        correct = river.nameEn;
        options = _getRiverOptions(river, 'en');
      }

      questions.add(QuizQuestion(
        question: question,
        correctAnswer: correct,
        options: options,
        emoji: '🌊',
        type: 'river',
      ));
    }

    questions.shuffle();
    return questions;
  }

  String _getProvinceName() {
    if (widget.language == 'Sinhala') return widget.province.nameSi;
    if (widget.language == 'Tamil') return widget.province.nameTa;
    return widget.province.nameEn;
  }

  List<String> _getAnimalOptions(Animal animal, String lang) {
    List<String> allAnimals = [
      'Elephant|අලියා|யானை',
      'Leopard|දිවියා|சிறுத்தை',
      'Crocodile|කිඹුලා|முதலை',
      'Monkey|වදුරා|குரங்கு',
      'Peacock|මොණරා|மயில்',
      'Dolphin|ඩොල්ෆිනා|டால்பின்',
      'Flamingo|ෆ්ලැමිංගෝ|ஃப்ளமிங்கோ',
      'Sea Turtle|කැස්බෑවා|ஆமை',
    ];

    String correct = lang == 'si'
        ? animal.nameSi
        : lang == 'ta'
            ? animal.nameTa
            : animal.nameEn;

    List<String> options = [correct];
    allAnimals.shuffle();

    for (var a in allAnimals) {
      if (options.length >= 4) break;
      List<String> parts = a.split('|');
      String name = lang == 'si'
          ? parts[1]
          : lang == 'ta'
              ? parts[2]
              : parts[0];
      if (name != correct) options.add(name);
    }

    options.shuffle();
    return options;
  }

  List<String> _getRiverOptions(River river, String lang) {
    List<String> allRivers = [
      'Kelani River|කැලණි ගඟ|கேலானி நதி',
      'Mahaweli River|මහවැලි ගඟ|மகாவலி நதி',
      'Kalu River|කළු ගඟ|காலு நதி',
      'Nilwala River|නිල්වලා ගඟ|நில்வாலா நதி',
      'Gin River|ගිං ගඟ|கின் நதி',
      'Deduru Oya|දැදුරු ඔය|தெதுரு ஓயா',
      'Gal Oya|ගල් ඔය|கல் ஓயா',
      'Malwathu Oya|මල්වතු ඔය|மல்வத்து ஓயா',
    ];

    String correct = lang == 'si'
        ? river.nameSi
        : lang == 'ta'
            ? river.nameTa
            : river.nameEn;

    List<String> options = [correct];
    allRivers.shuffle();

    for (var r in allRivers) {
      if (options.length >= 4) break;
      List<String> parts = r.split('|');
      String name = lang == 'si'
          ? parts[1]
          : lang == 'ta'
              ? parts[2]
              : parts[0];
      if (name != correct) options.add(name);
    }

    options.shuffle();
    return options;
  }

  void _selectAnswer(int index) {
    if (_answered) return;
    setState(() {
      _selectedAnswer = index;
      _answered = true;
      if (_questions[_currentQuestion].options[index] ==
          _questions[_currentQuestion].correctAnswer) {
        _score++;
      }
    });
  }

  void _nextQuestion() {
    if (_currentQuestion < _questions.length - 1) {
      setState(() {
        _currentQuestion++;
        _selectedAnswer = null;
        _answered = false;
      });
      _animController.reset();
      _animController.forward();
    } else {
      _showResult();
    }
  }

  void _showResult() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              _score >= _questions.length * 0.7 ? '🏆' : '⭐',
              style: const TextStyle(fontSize: 60),
            ),
            const SizedBox(height: 12),
            Text(
              _getResultTitle(),
              style: const TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: Color(0xFF1B5E20),
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              '$_score / ${_questions.length}',
              style: const TextStyle(
                fontSize: 36,
                fontWeight: FontWeight.bold,
                color: Color(0xFF0D47A1),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              _getResultMessage(),
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.black54),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () {
                      Navigator.pop(context);
                      Navigator.pop(context);
                    },
                    child: Text(_getHomeLabel()),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF0D47A1),
                      foregroundColor: Colors.white,
                    ),
                    onPressed: () {
                      Navigator.pop(context);
                      setState(() {
                        _currentQuestion = 0;
                        _score = 0;
                        _selectedAnswer = null;
                        _answered = false;
                        _questions.shuffle();
                      });
                    },
                    child: Text(_getRetryLabel()),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  String _getResultTitle() {
    bool good = _score >= _questions.length * 0.7;
    if (widget.language == 'Sinhala') return good ? 'චම්පියන්!' : 'නැවත උත්සාහ කරන්න!';
    if (widget.language == 'Tamil') return good ? 'சாம்பியன்!' : 'மீண்டும் முயற்சிக்கவும்!';
    return good ? 'Champion!' : 'Try Again!';
  }

  String _getResultMessage() {
    if (widget.language == 'Sinhala') return 'ඔබ $_score න් ${_questions.length} ක් නිවැරදිව පිළිතුරු දුන්නා!';
    if (widget.language == 'Tamil') return 'நீங்கள் ${_questions.length} இல் $_score சரியாக பதிலளித்தீர்கள்!';
    return 'You answered $_score out of ${_questions.length} correctly!';
  }

  String _getHomeLabel() {
    if (widget.language == 'Sinhala') return 'මුල් පිටුව';
    if (widget.language == 'Tamil') return 'முகப்பு';
    return 'Home';
  }

  String _getRetryLabel() {
    if (widget.language == 'Sinhala') return 'නැවත ක්‍රීඩා කරන්න';
    if (widget.language == 'Tamil') return 'மீண்டும் விளையாடு';
    return 'Play Again';
  }

  String _getNextLabel() {
    if (widget.language == 'Sinhala') return 'ඊළඟ ප්‍රශ්නය →';
    if (widget.language == 'Tamil') return 'அடுத்த கேள்வி →';
    return 'Next Question →';
  }

  String _getQuizTitle() {
    if (widget.language == 'Sinhala') return 'ප්‍රශ්නෝත්තර ක්‍රීඩාව';
    if (widget.language == 'Tamil') return 'வினாடி வினா';
    return 'Quiz Game';
  }

  @override
  Widget build(BuildContext context) {
    if (_questions.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: Text(_getQuizTitle())),
        body: const Center(child: Text('No questions available')),
      );
    }

    final question = _questions[_currentQuestion];
    final progress = (_currentQuestion + 1) / _questions.length;

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF4A148C), Color(0xFF7B1FA2), Color(0xFFF3E5F5)],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildQuizHeader(context, progress),
              Expanded(
                child: ScaleTransition(
                  scale: _scaleAnim,
                  child: _buildQuestionCard(question),
                ),
              ),
              if (_answered) _buildNextButton(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildQuizHeader(BuildContext context, double progress) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Row(
            children: [
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.white24,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(Icons.close, color: Colors.white),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  '${_currentQuestion + 1} / ${_questions.length}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.amber,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  '⭐ $_score',
                  style: const TextStyle(
                    color: Colors.black87,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: LinearProgressIndicator(
              value: progress,
              backgroundColor: Colors.white24,
              valueColor: const AlwaysStoppedAnimation<Color>(Colors.amber),
              minHeight: 8,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuestionCard(QuizQuestion question) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.1),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Column(
              children: [
                Text(question.emoji, style: const TextStyle(fontSize: 60)),
                const SizedBox(height: 12),
                Text(
                  question.question,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF4A148C),
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          ...question.options.asMap().entries.map((entry) {
            return _buildOptionButton(entry.key, entry.value, question);
          }),
        ],
      ),
    );
  }

  Widget _buildOptionButton(int index, String option, QuizQuestion question) {
    Color bgColor = Colors.white;
    Color textColor = const Color(0xFF4A148C);
    IconData? icon;

    if (_answered) {
      if (option == question.correctAnswer) {
        bgColor = const Color(0xFF2E7D32);
        textColor = Colors.white;
        icon = Icons.check_circle;
      } else if (index == _selectedAnswer) {
        bgColor = const Color(0xFFC62828);
        textColor = Colors.white;
        icon = Icons.cancel;
      }
    }

    return GestureDetector(
      onTap: () => _selectAnswer(index),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: _answered && option == question.correctAnswer
                ? const Color(0xFF2E7D32)
                : Colors.white54,
            width: 2,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.08),
              blurRadius: 6,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          children: [
            Expanded(
              child: Text(
                option,
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w600,
                  color: textColor,
                ),
              ),
            ),
            if (icon != null) Icon(icon, color: textColor, size: 22),
          ],
        ),
      ),
    );
  }

  Widget _buildNextButton() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: SizedBox(
        width: double.infinity,
        child: ElevatedButton(
          onPressed: _nextQuestion,
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.amber,
            foregroundColor: Colors.black87,
            padding: const EdgeInsets.symmetric(vertical: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            elevation: 4,
          ),
          child: Text(
            _currentQuestion < _questions.length - 1
                ? _getNextLabel()
                : widget.language == 'Sinhala'
                    ? 'ප්‍රතිඵල බලන්න 🏆'
                    : widget.language == 'Tamil'
                        ? 'முடிவுகளை பார்க்கவும் 🏆'
                        : 'See Results 🏆',
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }
}

class QuizQuestion {
  final String question;
  final String correctAnswer;
  final List<String> options;
  final String emoji;
  final String type;

  QuizQuestion({
    required this.question,
    required this.correctAnswer,
    required this.options,
    required this.emoji,
    required this.type,
  });
}