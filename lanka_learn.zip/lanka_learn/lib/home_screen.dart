import 'package:flutter/material.dart';
import 'data/provinces_data.dart';
import 'province_screen.dart';

class HomeScreen extends StatefulWidget {
  final String language;
  final Function(String) onLanguageChange;

  const HomeScreen({
    super.key,
    required this.language,
    required this.onLanguageChange,
  });

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String getProvinceName(Province p) {
    if (widget.language == 'Sinhala') return p.nameSi;
    if (widget.language == 'Tamil') return p.nameTa;
    return p.nameEn;
  }

  String getTitle() {
    if (widget.language == 'Sinhala') return 'පළාත් තෝරන්න';
    if (widget.language == 'Tamil') return 'மாகாணம் தேர்ந்தெடுக்கவும்';
    return 'Choose a Province';
  }

  String getSubtitle() {
    if (widget.language == 'Sinhala') return 'ශ්‍රී ලංකාවේ සතුන් හා ගංඟා ගවේෂණය කරන්න';
    if (widget.language == 'Tamil') return 'இலங்கையின் விலங்குகள் மற்றும் ஆறுகளை ஆராயுங்கள்';
    return 'Explore animals and rivers of Sri Lanka';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF1B5E20),
              Color(0xFF4CAF50),
              Color(0xFFE8F5E9),
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              // _buildLanguageSelector(),
              Expanded(child: _buildProvinceGrid()),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          const Text('🇱🇰', style: TextStyle(fontSize: 50)),
          const SizedBox(height: 8),
          Text(
            getTitle(),
            style: const TextStyle(
              fontSize: 26,
              fontWeight: FontWeight.bold,
              color: Colors.white,
              shadows: [Shadow(color: Colors.black26, blurRadius: 4)],
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 6),
          Text(
            getSubtitle(),
            style: const TextStyle(fontSize: 13, color: Colors.white70),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  // Widget _buildLanguageSelector() {
  //   return Padding(
  //     padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
  //     child: Container(
  //       decoration: BoxDecoration(
  //         color: Colors.white24,
  //         borderRadius: BorderRadius.circular(30),
  //       ),
  //       child: Row(
  //         mainAxisSize: MainAxisSize.min,
  //         children: ['English', 'Sinhala', 'Tamil'].map((lang) {
  //           final selected = widget.language == lang;
  //           return GestureDetector(
  //             onTap: () => widget.onLanguageChange(lang),
  //             child: AnimatedContainer(
  //               duration: const Duration(milliseconds: 200),
  //               padding: const EdgeInsets.symmetric(
  //                 horizontal: 16,
  //                 vertical: 8,
  //               ),
  //               decoration: BoxDecoration(
  //                 color: selected ? Colors.white : Colors.transparent,
  //                 borderRadius: BorderRadius.circular(30),
  //               ),
  //               child: Text(
  //                 lang,
  //                 style: TextStyle(
  //                   color: selected
  //                       ? const Color(0xFF1B5E20)
  //                       : Colors.white,
  //                   fontWeight:
  //                       selected ? FontWeight.bold : FontWeight.normal,
  //                   fontSize: 13,
  //                 ),
  //               ),
  //             ),
  //           );
  //         }).toList(),
  //       ),
  //     ),
  //   );
  // }

  Widget _buildProvinceGrid() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: GridView.builder(
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          childAspectRatio: 1.1,
        ),
        itemCount: provinces.length,
        itemBuilder: (context, index) {
          final province = provinces[index];
          return _buildProvinceCard(province);
        },
      ),
    );
  }

  Widget _buildProvinceCard(Province province) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => ProvinceScreen(
              province: province,
              language: widget.language,
            ),
          ),
        );
      },
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(province.emoji, style: const TextStyle(fontSize: 40)),
            const SizedBox(height: 8),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: Text(
                getProvinceName(province),
                style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF1B5E20),
                ),
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            const SizedBox(height: 4),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text('🐘', style: TextStyle(fontSize: 12)),
                Text(
                  ' ${province.animals.length}  ',
                  style: const TextStyle(fontSize: 11, color: Colors.grey),
                ),
                const Text('🌊', style: TextStyle(fontSize: 12)),
                Text(
                  ' ${province.rivers.length}',
                  style: const TextStyle(fontSize: 11, color: Colors.grey),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}