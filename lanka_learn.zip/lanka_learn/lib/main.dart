import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'welcome_screen.dart';
import 'home_screen.dart';
import 'all_quiz_screen.dart';
import 'profile_screen.dart';

void main() {
  runApp(const LankaLearnApp());
}

class LankaLearnApp extends StatefulWidget {
  const LankaLearnApp({super.key});

  @override
  State<LankaLearnApp> createState() => _LankaLearnAppState();
}

class _LankaLearnAppState extends State<LankaLearnApp> {
  String _language = 'English';
  bool _loading = true;
  bool _hasProfile = false;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _hasProfile = prefs.getBool('hasProfile') ?? false;
      _language = prefs.getString('language') ?? 'English';
      _loading = false;
    });
  }

  void setLanguage(String lang) {
    setState(() => _language = lang);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Lanka Learn',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF2E7D32),
          primary: const Color(0xFF2E7D32),
          secondary: const Color(0xFF1565C0),
        ),
        useMaterial3: true,
      ),
      routes: {
        '/home': (context) => MainScreen(
              language: _language,
              onLanguageChange: setLanguage,
            ),
      },
      home: _loading
          ? const SplashScreen()
          : _hasProfile
              ? MainScreen(
                  language: _language,
                  onLanguageChange: setLanguage,
                )
              : const WelcomeScreen(),
    );
  }
}

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: Color(0xFF1B5E20),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('🇱🇰', style: TextStyle(fontSize: 80)),
            SizedBox(height: 16),
            Text(
              'Lanka Learn',
              style: TextStyle(
                fontSize: 32,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            SizedBox(height: 24),
            CircularProgressIndicator(color: Colors.white),
          ],
        ),
      ),
    );
  }
}

class MainScreen extends StatefulWidget {
  final String language;
  final Function(String) onLanguageChange;

  const MainScreen({
    super.key,
    required this.language,
    required this.onLanguageChange,
  });

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _currentIndex = 0;
  String _name = '';
  String _avatar = '🦁';

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _name = prefs.getString('name') ?? '';
      _avatar = prefs.getString('avatar') ?? '🦁';
    });
  }

  String _getHomeLabel() {
    if (widget.language == 'Sinhala') return 'මුල් පිටුව';
    if (widget.language == 'Tamil') return 'முகப்பு';
    return 'Home';
  }

  String _getQuizLabel() {
    if (widget.language == 'Sinhala') return 'ක්‍රීඩා';
    if (widget.language == 'Tamil') return 'வினாடி வினா';
    return 'Quiz';
  }

  String _getProfileLabel() {
    if (widget.language == 'Sinhala') return 'පැතිකඩ';
    if (widget.language == 'Tamil') return 'சுயவிவரம்';
    return 'Profile';
  }

  @override
  Widget build(BuildContext context) {
    final screens = [
      HomeScreen(
        language: widget.language,
        onLanguageChange: widget.onLanguageChange,
      ),
      AllQuizScreen(language: widget.language),
      ProfileScreen(
        language: widget.language,
        onLanguageChange: (lang) {
          widget.onLanguageChange(lang);
          _loadProfile();
        },
      ),
    ];

    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: screens,
      ),
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          boxShadow: [
            BoxShadow(
              color: Colors.black12,
              blurRadius: 10,
              offset: Offset(0, -2),
            ),
          ],
        ),
        child: BottomNavigationBar(
          currentIndex: _currentIndex,
          onTap: (index) async {
            if (index == 2) await _loadProfile();
            setState(() => _currentIndex = index);
          },
          selectedItemColor: const Color(0xFF2E7D32),
          unselectedItemColor: Colors.grey,
          selectedLabelStyle: const TextStyle(fontWeight: FontWeight.bold),
          type: BottomNavigationBarType.fixed,
          items: [
            BottomNavigationBarItem(
              icon: const Icon(Icons.home_rounded),
              label: _getHomeLabel(),
            ),
            BottomNavigationBarItem(
              icon: const Icon(Icons.sports_esports_rounded),
              label: _getQuizLabel(),
            ),
            BottomNavigationBarItem(
              icon: _currentIndex == 2
                  ? Text(_avatar, style: const TextStyle(fontSize: 24))
                  : Text(_avatar, style: const TextStyle(fontSize: 20)),
              label: _name.isEmpty ? _getProfileLabel() : _name,
            ),
          ],
        ),
      ),
    );
  }
}